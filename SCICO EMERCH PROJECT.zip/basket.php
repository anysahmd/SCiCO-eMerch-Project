<?php
$title = "Basket";
include_once 'layout/header.php';

// Fetch product details for cart items
function get_cart_items($conn, $cart)
{
  $items = [];
  if (empty($cart)) {
    return $items;
  }

  foreach ($cart as $cart_key => $cart_item) {
    list($product_id, $variant_name) = explode(':', $cart_key . ':');
    $query = "SELECT p.id, p.name, p.price, p.image, pv.variant_name, pv.variant_stock 
                  FROM products p 
                  LEFT JOIN product_variants pv ON p.id = pv.product_id 
                  WHERE p.id = ? AND (pv.variant_name = ? OR pv.variant_name IS NULL)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'is', $product_id, $variant_name);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($product = mysqli_fetch_assoc($result)) {
      $product['quantity'] = $cart_item['quantity'];
      $product['variant_name'] = $variant_name ?: '';
      $items[] = $product;
    }
    mysqli_stmt_close($stmt);
  }

  return $items;
}

// Handle cart updates (update quantity or remove item)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['update_cart'])) {
    $product_id = (int)$_POST['product_id'];
    $variant_name = isset($_POST['variant_name']) ? mysqli_real_escape_string($conn, $_POST['variant_name']) : '';
    $quantity = max(1, (int)$_POST['quantity']);
    $cart_key = $product_id . ($variant_name ? ':' . $variant_name : '');

    if (isset($_SESSION['cart'][$cart_key])) {
      $_SESSION['cart'][$cart_key]['quantity'] = $quantity;
    }
  } elseif (isset($_POST['remove_item'])) {
    $product_id = (int)$_POST['product_id'];
    $variant_name = isset($_POST['variant_name']) ? mysqli_real_escape_string($conn, $_POST['variant_name']) : '';
    $cart_key = $product_id . ($variant_name ? ':' . $variant_name : '');

    unset($_SESSION['cart'][$cart_key]);
  }

  header('Location: basket.php');
  exit;
}

// Get cart items and calculate total
$cart_items = get_cart_items($conn, $_SESSION['cart'] ?? []);
$total_price = array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $cart_items));
?>

<div class="main">
  <!-- Header Section -->
  <div class="header">
    <h1>Your Basket</h1>
    <a href="index.php" class="basket-btn">
      <i class='bx bx-arrow-back'></i> Continue Shopping
    </a>
  </div>

  <!-- Cart Items Section -->
  <div class="products">
    <h2>Cart Items</h2>
    <?php if (empty($cart_items)): ?>
      <div class="alert alert-success">Your cart is empty.</div>
    <?php else: ?>
      <div class="cart-table-container">
        <table class="cart-table">
          <thead>
            <tr>
              <th>Image</th>
              <th>Product</th>
              <th>Variant</th>
              <th>Price</th>
              <th>Quantity</th>
              <th>Subtotal</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($cart_items as $item): ?>
              <tr>
                <td>
                  <img src="assets/img/product/<?= htmlspecialchars($item['image'] ?: 'default.png') ?>"
                    alt="<?= htmlspecialchars($item['name']) ?>"
                    width="100"
                    onerror="this.src='assets/img/product/default.png'">
                </td>
                <td><?= htmlspecialchars($item['name']) ?></td>
                <td><?= $item['variant_name'] ? htmlspecialchars($item['variant_name']) : '-' ?></td>
                <td>RM<?= number_format($item['price'], 2) ?></td>
                <td>
                  <form method="POST" class="cart-item-form">
                    <input type="hidden" name="product_id" value="<?= $item['id'] ?>">
                    <input type="hidden" name="variant_name" value="<?= htmlspecialchars($item['variant_name']) ?>">
                    <input type="number" name="quantity" min="1" value="<?= $item['quantity'] ?>" class="form-control" required style="width: 80px;">
                    <button type="submit" name="update_cart" class="btn btn-primary">Update</button>
                  </form>
                </td>
                <td>RM<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                <td>
                  <form method="POST" action="" class="cart-item-form">
                    <input type="hidden" name="product_id" value="<?= $item['id'] ?>">
                    <input type="hidden" name="variant_name" value="<?= htmlspecialchars($item['variant_name']) ?>">
                    <button type="submit" name="remove_item" class="btn btn-danger">Remove</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div class="cart-summary">
        <h3>Total: RM<?= number_format($total_price, 2) ?></h3>
        <a href="payment.php" class="checkout-btn">Proceed to Checkout</a>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php include_once 'layout/footer.php'; ?>