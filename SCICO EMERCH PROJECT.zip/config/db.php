<?php
session_start();

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '@Kaito0827');
define('DB_DATABASE', 'isp250project');
define('DB_PORT', '3307'); // Adjust the port if necessary

$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE, DB_PORT);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}