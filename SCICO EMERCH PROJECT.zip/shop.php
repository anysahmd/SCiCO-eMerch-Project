<?php
$title = "Shop";
include_once 'layout/header.php';

// Fetch products with variants
function fetch_products($conn, $search = '')
{
    $query = "SELECT p.*, pv.variant_name, pv.variant_stock 
              FROM products p 
              LEFT JOIN product_variants pv ON p.id = pv.product_id 
              WHERE p.price > 0";

    if ($search) {
        $search = mysqli_real_escape_string($conn, $search);
        $query .= " AND (p.name LIKE '%$search%' OR p.description LIKE '%$search%')";
    }

    $query .= " ORDER BY p.created_at DESC";
    $result = mysqli_query($conn, $query);
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

// Handle add to cart
function add_to_cart($product_id, $variant_name, $quantity)
{
    $cart_key = $product_id . ($variant_name ? ':' . $variant_name : '');

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    if (isset($_SESSION['cart'][$cart_key])) {
        $_SESSION['cart'][$cart_key]['quantity'] += $quantity;
    } else {
        $_SESSION['cart'][$cart_key] = [
            'product_id' => $product_id,
            'variant_name' => $variant_name,
            'quantity' => $quantity
        ];
    }
}

// Process search and cart actions
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$products = fetch_products($conn, $search);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $product_id = (int)$_POST['product_id'];
    $variant_name = isset($_POST['variant_name']) ? mysqli_real_escape_string($conn, $_POST['variant_name']) : '';
    $quantity = max(1, (int)$_POST['quantity']);

    add_to_cart($product_id, $variant_name, $quantity);
    header('Location: index.php?added=1');
    exit;
}
?>

<div class="main">
    <!-- Header Section -->
    <div class="header">
        <h1>Shop</h1>
        <div style="display: flex; gap: 15px; align-items: center;">
            <form method="GET" style="display: flex; gap: 10px;">
                <input type="text" name="search" placeholder="Search products..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit" class="search-btn">Search</button>
            </form>
            <a href="basket.php" class="basket-btn">
                <i class='bx bx-cart'></i> Basket
                <?php if (!empty($_SESSION['cart'])): ?>
                    <span class="cart-count"><?= array_sum(array_column($_SESSION['cart'], 'quantity')) ?></span>
                <?php endif; ?>
            </a>
        </div>
    </div>

    <!-- Success Message -->
    <?php if (isset($_GET['added'])): ?>
        <div class="alert success">Item added to cart!</div>
    <?php endif; ?>

    <!-- Products Section -->
    <div class="products">
        <h2>SCiCO OFFICIAL MERCHANDISE</h2>
        <div class="product-grid">
            <div class="row">

                <?php
                $current_product_id = null;
                foreach ($products as $index => $product):
                    if ($current_product_id !== $product['id']):
                        $current_product_id = $product['id'];
                        $variants = array_filter($products, fn($p) => $p['id'] === $current_product_id);
                        $has_variants = count(array_filter($variants, fn($v) => !empty($v['variant_name']))) > 0;
                        $original_price = $product['price'] + 15; // Fixed discount for display

                        // Start new row every 4 products
                        if ($index > 0 && $index % 4 === 0): ?>
            </div>
            <div class="row">
            <?php endif; ?>
            <div class="col-3">
                <div class="card">
                    <span class="sale">Sale</span>
                    <img src="assets/img/product/<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                    <h3><?= htmlspecialchars($product['name']) ?></h3>
                    <p>
                        <del>RM<?= number_format($original_price, 2) ?></del>
                        <strong>RM<?= number_format($product['price'], 2) ?></strong>
                    </p>
                    <form method="POST" action="">
                        <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                        <?php if ($has_variants): ?>
                            <label>
                                Variant:
                                <select name="variant_name">
                                    <?php foreach ($variants as $variant):
                                        if (!empty($variant['variant_name'])): ?>
                                            <option value="<?= htmlspecialchars($variant['variant_name']) ?>"
                                                <?= $variant['variant_stock'] <= 0 ? 'disabled' : '' ?>>
                                                <?= htmlspecialchars($variant['variant_name']) ?>
                                                (Stock: <?= $variant['variant_stock'] ?>)
                                            </option>
                                    <?php endif;
                                    endforeach; ?>
                                </select>
                            </label>
                        <?php endif; ?>
                        <label>
                            Qty:
                            <input type="number" name="quantity" min="1" value="1" required>
                        </label>
                        <button type="submit" name="add_to_cart"
                            <?= $product['variant_stock'] <= 0 && $has_variants ? 'disabled' : '' ?>>
                            Add to cart
                        </button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<?php include_once 'layout/footer.php'; ?>