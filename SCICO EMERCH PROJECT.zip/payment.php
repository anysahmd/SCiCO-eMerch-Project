<?php $title = "Payment"; ?>
<?php include_once 'layout/header.php'; ?>
<style>
  /* Top Bar */
  .top-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: white;
    padding: 15px 20px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    margin-bottom: 30px;
  }

  .top-bar h2 {
    font-size: 24px;
    color: #1e3a8a;
  }

  .top-bar .search-form {
    display: flex;
    align-items: center;
  }

  .top-bar input {
    padding: 10px 20px;
    border-radius: 25px;
    border: 1px solid #e2e8f0;
    font-size: 16px;
    width: 250px;
    transition: border-color 0.3s ease;
  }

  .top-bar input:focus {
    outline: none;
    border-color: #0e0581;
    box-shadow: 0 0 0 3px rgba(14, 5, 129, 0.1);
  }

  @media (max-width: 768px) {
    .top-bar {
      flex-direction: column;
      gap: 15px;
      align-items: flex-start;
    }

    .top-bar input {
      width: 100%;
    }
  }

  /* Step Label */
  .step-label {
    text-align: center;
    font-size: 16px;
    color: #4b5563;
    margin-bottom: 30px;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 1px;
  }

  .step-label strong {
    color: #0e0581;
  }

  /* Payment Box */
  .payment-box {
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    max-width: 600px;
    margin: 0 auto;
    text-align: center;
  }

  .payment-box h3 {
    font-size: 20px;
    color: #1e3a8a;
    margin-bottom: 20px;
  }

  .payment-box p {
    font-size: 16px;
    color: #4b5563;
    margin-bottom: 20px;
    line-height: 1.6;
  }

  .payment-box .upload-form {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 15px;
  }
</style>
<?php

$total = 0;
function generate_invoice_number()
{
  // COUNT TODAY THIS ORDER
  global $conn;
  $today = date('Y-m-d');
  $sql_count = "SELECT COUNT(*) as count FROM orders WHERE DATE(created_at) = ?";
  $stmt_count = mysqli_prepare($conn, $sql_count);

  mysqli_stmt_bind_param($stmt_count, 's', $today);
  mysqli_stmt_execute($stmt_count);
  $result_count = mysqli_stmt_get_result($stmt_count);
  $count = mysqli_fetch_assoc($result_count)['count'];
  mysqli_stmt_close($stmt_count);

  return sprintf("INV-%s-%05d", date('Ymd'), $count + 1);
}
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
  // Calculate total amount
  foreach ($_SESSION['cart'] as $item) {
    $product_id = $item['product_id'];
    $variant_name = $item['variant_name'];
    $quantity = $item['quantity'];

    // Fetch product details from the database
    $query = "SELECT `price` FROM products WHERE id = '$product_id'";
    $result = mysqli_query($conn, $query);
    if ($result && mysqli_num_rows($result) > 0) {
      $product = mysqli_fetch_assoc($result);
      $price = $product['price'];

      // Calculate subtotal for this item
      $subtotal = $price * $quantity;
      $total += $subtotal;
    }
  }

  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['payment_proof'])) {
    $user_id = $_SESSION['users']['id'] ?? null;
    if (!$user_id) {
      echo "<script>alert('Please log in to proceed with payment.'); window.location.href = 'login.php';</script>";
      exit;
    }

    $payment_proof = $_FILES['payment_proof'];
    $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];
    $max_size = 10 * 1024 * 1024; // 10MB

    if (in_array($payment_proof['type'], $allowed_types) && $payment_proof['size'] <= $max_size) {
      $upload_dir = 'assets/payment_proofs/';
      $file_name = uniqid() . '-' . basename($payment_proof['name']);
      $target_file = $upload_dir . $file_name;

      if (move_uploaded_file($payment_proof['tmp_name'], $target_file)) {
        // Insert order into database
        $query = "INSERT INTO orders (user_id, total_price, payment_proof, invoice_number) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $query);
        $invoice_number = generate_invoice_number();
        mysqli_stmt_bind_param($stmt, 'idss', $user_id, $total, $file_name, $invoice_number);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Selepas mysqli_stmt_execute($stmt);
        $order_id = mysqli_insert_id($conn);

        // Simpan setiap item dalam order_details
        foreach ($_SESSION['cart'] as $item) {
          $product_id = $item['product_id'];
          $variant_name = $item['variant_name'];
          $quantity = $item['quantity'];

          // Dapatkan variant_id jika perlu
          $variant_id = null;
          if (!empty($variant_name)) {
            $variant_query = "SELECT id FROM product_variants WHERE product_id = ? AND variant_name = ?";
            $stmt_variant = mysqli_prepare($conn, $variant_query);
            mysqli_stmt_bind_param($stmt_variant, 'is', $product_id, $variant_name);
            mysqli_stmt_execute($stmt_variant);
            $result_variant = mysqli_stmt_get_result($stmt_variant);
            if ($variant = mysqli_fetch_assoc($result_variant)) {
              $variant_id = $variant['id'];
            }
            mysqli_stmt_close($stmt_variant);
          }

          // Get product price again (you can cache this earlier)
          $product_query = "SELECT price FROM products WHERE id = ?";
          $stmt_product = mysqli_prepare($conn, $product_query);
          mysqli_stmt_bind_param($stmt_product, 'i', $product_id);
          mysqli_stmt_execute($stmt_product);
          $result_product = mysqli_stmt_get_result($stmt_product);
          $product = mysqli_fetch_assoc($result_product);
          $price = $product['price'];
          mysqli_stmt_close($stmt_product);

          // Insert into order_details
          $insert_detail = "INSERT INTO order_details (order_id, product_id, variant_id, quantity, price) VALUES (?, ?, ?, ?, ?)";
          $stmt_detail = mysqli_prepare($conn, $insert_detail);
          mysqli_stmt_bind_param($stmt_detail, 'iiiid', $order_id, $product_id, $variant_id, $quantity, $price);
          mysqli_stmt_execute($stmt_detail);
          mysqli_stmt_close($stmt_detail);

          if ($variant_id) {
            $update_stock = "UPDATE product_variants SET variant_stock = variant_stock - ? WHERE id = ?";
            $stmt_update = mysqli_prepare($conn, $update_stock);
            mysqli_stmt_bind_param($stmt_update, 'ii', $quantity, $variant_id);
            mysqli_stmt_execute($stmt_update);
          }
        }
        unset($_SESSION['cart']);

        echo "<script>alert('Payment proof uploaded successfully. Your order has been placed.'); window.location.href = 'invoice.php?order_id=$order_id';</script>";
      } else {
        echo "<script>alert('Failed to upload payment proof. Please try again.');</script>";
      }
    } else {
      echo "<script>alert('Invalid file type or size exceeded. Please upload a valid file.');</script>";
    }
  }
} else {
  echo "<script>alert('Your cart is empty. Please add items to your cart before proceeding to payment.'); window.location.href = 'basket.php';</script>";
}

?>
<!-- Main Content -->
<div class="main">
  <div class="top-bar">
    <h2>Payment</h2>
  </div>

  <div class="step-label">
    BASKET ► <strong>PAYMENT</strong>► INVOICE
  </div>

  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="card">
          <h3 id="invoice-display">PROOF OF PAYMENT - #00003</h3>
          <p>Transfer to:<br>
            MYTECC CLUB<br>
            7072119000 CIMB Bank</p>
          <p>Total Amount: RM<?= number_format($total, 2) ?></p>
          <form class="" enctype="multipart/form-data" method="POST" action="">
            <div class="form-group">
              <label for="payment-proof">Upload Proof of Payment</label>
              <input type="file" id="payment-proof" name="payment_proof" accept=".jpg,.jpeg,.png,.pdf" class="form-control" required />
            </div>
            <button type="submit" class="upload-btn btn btn-primary">Upload</button>
          </form>

          <p class="note">File type: .jpg, .jpeg, .png, & .pdf only & max 10MB</p>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include_once 'layout/footer.php'; ?>