<?php require_once 'config/db.php'; ?>
<?php if (!isset($_SESSION['users']) && !isset($_SESSION['admin'])): ?>
    <script>
        alert("Please log in to access this page.");
        window.location.href = "login.php";
    </script>
    <?php exit; ?>
<?php endif; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SCiCO Shop</title>
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/custom.css">
</head>

<body>
    <div class="sidebar">
        <h2>SCiCO</h2>
        <a href="shop.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'shop.php') ? 'active' : ''; ?>"><i class='bx bx-store'></i> Shop</a>
        <a href="basket.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'basket.php') ? 'active' : ''; ?>"><i class='bx bx-cart'></i> Orders</a>
        <a href="my-orders.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'my-orders.php') ? 'active' : ''; ?>"><i class='bx bx-package'></i> My Orders</a>
        <a href="account-details.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'account-details.php') ? 'active' : ''; ?>"><i class='bx bx-user'></i> Accounts</a>
        <a href="#" onclick="logout()"><i class='bx bx-log-out'></i> Log Out</a>
    </div>