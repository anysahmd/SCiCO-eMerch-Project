<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
  <style>
    * {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      display: flex;
      background-color: #f5f5f5;
    }
    .sidebar {
      width: 240px;
      background: #0e0581;
      color: white;
      height: 100vh;
      padding: 20px;
    }
    .sidebar h2 {
      text-align: center;
      margin-bottom: 30px;
    }
    .sidebar a {
      display: flex;
      align-items: center;
      padding: 15px 20px;
      color: white;
      text-decoration: none;
      border-radius: 6px;
      transition: background 0.3s;
    }
    .sidebar a:hover, .sidebar a.active {
      background: white;
      color: #0e0581;
      font-weight: bold;
    }
    .main {
      flex: 1;
      padding: 30px;
    }
    .topbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }
    .topbar h1 {
      color: #333;
    }
    .order-container {
      background: white;
      padding: 20px;
      border-radius: 12px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    table th, table td {
      border: 1px solid #ddd;
      padding: 12px;
      text-align: center;
      font-size: 14px;
    }
    table th {
      background-color: #f0f0f0;
    }
    .status {
      color: orange;
      font-weight: 600;
    }
    .total {
      text-align: right;
      font-weight: bold;
      padding: 10px 0;
    }

  </style>
</head>
<body>
  <div class="sidebar">
    <h2>SCiCO</h2>
    <a href="#" class="active">Shop</a>
    <a href="#">Orders</a>
    <a href="#">Accounts</a>
    <a href="#">Log Out</a>
  </div>
  <div class="main">
    <div class="topbar">
      <h1>Orders</h1>
    </div>

    <div class="order-container">
      <p><strong>Invoice:</strong> #00003<br>
         <strong>Date:</strong> 2025-06-30<br>
         <strong>Time:</strong> 11:15:09</p>

      <table>
        <thead>
          <tr>
            <th>Invoice</th>
            <th>Product</th>
            <th>Name</th>
            <th>Size</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Date Order</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>#00003</td>
            <td><img src="men.jpg" alt="Corporate Shirt Men" width="60"></td>
            <td>Corporate Shirt Men</td>
            <td>M</td>
            <td>1</td>
            <td>RM45.00</td>
            <td>2025-06-30</td>
            <td class="status">pending</td>
          </tr>
          <tr>
            <td>#00003</td>
            <td><img src="jerseyy.jpeg" alt="T-Shirt" width="60"></td>
            <td>MYTECC T-Shirt 2019 Edition</td>
            <td>M</td>
            <td>1</td>
            <td>RM35.00</td>
            <td>2025-06-30</td>
            <td class="status">pending</td>
          </tr>
        </tbody>
      </table>
      <div class="total">Delivery Fee: + RM5.00<br>Total: RM85.00</div>
    </div>
  </div>
</body>
</html>
