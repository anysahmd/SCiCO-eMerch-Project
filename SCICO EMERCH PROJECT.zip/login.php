<?php
require_once 'config/db.php';

// Initialize variables
$username = '';
$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate input
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username)) $errors[] = "Username or email is required.";
    if (empty($password)) $errors[] = "Password is required.";

    // Check credentials
    if (empty($errors)) {
        $sql = "SELECT * FROM `users` WHERE `username` = ? OR `email` = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ss", $username, $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);
            if (password_verify($password, $user['password'])) {
                // Set session variables
                $_SESSION['users'] = $user;
                echo "<script>alert('Login successful!'); window.location.href = 'index.php';</script>";
            } else {
                $errors[] = "Incorrect password.";
            }
        } else {
            $errors[] = "Username or email not found.";
        }
        mysqli_stmt_close($stmt);
    }

    // Display errors if any
    if (!empty($errors)) {
        $error_message = implode("\\n", array_map('addslashes', $errors));
        echo "<script>alert('$error_message');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/login.css?v=1.0">
</head>

<body>
    <div class="wrapper">
        <form action="" method="POST">
            <h1>Login</h1>
            <div class="input-box">
                <input type="text" placeholder="Username or Email" name="username" required value="<?php echo htmlspecialchars($username); ?>">
                <i class='bx bxs-user'></i>
            </div>
            <br>
            <div class="input-box">
                <input type="password" placeholder="Password" name="password" required>
                <i class='bx bxs-lock-alt'></i>
            </div>
            <br>
            <button type="submit" class="btn">Login</button>
            <div class="register-link">
                <p>Don't have an account? <a href="register.php">Sign Up</a></p>
            </div>
        </form>
    </div>
</body>

</html>