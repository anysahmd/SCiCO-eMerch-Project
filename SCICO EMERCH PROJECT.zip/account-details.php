<?php $title = "Account Details"; ?>
<?php include_once 'layout/header.php'; ?>
<?php

$user_id = $_SESSION['users']['id'] ?? null;
if (!$user_id) {
  echo "<script>alert('Please log in to view your account details.'); window.location.href = 'login.php';</script>";
  exit;
}

$sql_user = "SELECT * FROM `users` WHERE `id`='$user_id'";
$result_user = mysqli_query($conn, $sql_user);
if (mysqli_num_rows($result_user) > 0) {
  $user = mysqli_fetch_assoc($result_user);
} else {
  echo "<script>alert('User not found.'); window.location.href = 'login.php';</script>";
  exit;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = trim($_POST['username'] ?? '');
  $email = trim($_POST['email'] ?? '');
  $name = trim($_POST['name'] ?? '');
  $address = trim($_POST['address'] ?? '');
  $phone = trim($_POST['phone'] ?? '');
  $password = $_POST['password'] ?? '';
  $confirm_password = $_POST['confirm_password'] ?? '';

  // Validate inputs
  if (empty($username) || empty($email) || empty($name) || empty($address) || empty($phone)) {
    echo "<script>alert('All fields are required.');</script>";
    exit;
  }

  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "<script>alert('Invalid email format.');</script>";
    exit;
  }

  if ($password && $password !== $confirm_password) {
    echo "<script>alert('Passwords do not match.');</script>";
    exit;
  }

  // Update user details
  $update_sql = "UPDATE `users` SET `username`=?, `email`=?, `name`=?, `address`=?, `phone`=? WHERE `id`=?";
  $stmt = mysqli_prepare($conn, $update_sql);

  if ($password) {
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    mysqli_stmt_bind_param($stmt, "sssssi", $username, $email, $name, $address, $phone, $user_id);
    mysqli_stmt_execute($stmt);

    // Update password
    $update_password_sql = "UPDATE `users` SET `password`=? WHERE `id`=?";
    $password_stmt = mysqli_prepare($conn, $update_password_sql);
    mysqli_stmt_bind_param($password_stmt, "si", $hashed_password, $user_id);
    mysqli_stmt_execute($password_stmt);
    mysqli_stmt_close($password_stmt);
  } else {
    mysqli_stmt_bind_param($stmt, "sssssi", $username, $email, $name, $address, $phone, $user_id);
    mysqli_stmt_execute($stmt);
  }

  mysqli_stmt_close($stmt);

  echo "<script>alert('Account details updated successfully!'); window.location.href = 'account-details.php';</script>";
}

?>
<div class="main">
  <!-- Header Section -->
  <div class="header">
    <h1>Your Account Details</h1>
  </div>

  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <h4 class="card-title">
              Account Details
            </h4>
          </div>
          <div class="card-body">
            <form action="" method="POST">
              <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
              </div>
              <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
              </div>
              <div class="form-group">
                <label for="name">Full Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
              </div>
              <div class="form-group">
                <label for="address">Address</label>
                <input type="text" class="form-control" id="address" name="address" value="<?php echo htmlspecialchars($user['address']); ?>" required>
              </div>
              <div class="form-group">
                <label for="phone">Phone</label>
                <input type="text" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
              </div>

              <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Leave blank to keep current password">
              </div>

              <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Leave blank to keep current password">
              </div>
              <button type="submit" class="btn btn-primary">Update Account</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include_once 'layout/footer.php'; ?>