<?php $title = "My Orders"; ?>
<?php require_once 'layout/header.php'; ?>
<?php require_once 'config/db.php'; ?>
<?php
$user_id = $_SESSION['users']['id'] ?? null;
if (!$user_id) {
    echo "<script>alert('Please log in to view your orders.'); window.location.href = 'login.php';</script>";
    exit;
}

// Fetch user's orders
$query = "SELECT * FROM orders WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$orders = mysqli_fetch_all($result, MYSQLI_ASSOC);
mysqli_stmt_close($stmt);

// Fetch order details for each order
$order_details = [];
foreach ($orders as $order) {
    $order_id = $order['id'];
    $query = "SELECT od.*, p.name AS product_name, p.price, pv.variant_name 
              FROM order_details od 
              JOIN products p ON od.product_id = p.id 
              LEFT JOIN product_variants pv ON od.variant_id = pv.id 
              WHERE od.order_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'i', $order_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $order_details[$order_id] = mysqli_fetch_all($result, MYSQLI_ASSOC);
    mysqli_stmt_close($stmt);
}

// Function to format date
function format_date($date)
{
    return date("F j, Y", strtotime($date));
}

// Function to format price
function format_price($price)
{
    return number_format($price, 2, '.', ',');
}

?>

<!-- Main Content -->
<div class="main">
    <div class="top-bar">
        <h2>My Orders</h2>
    </div>


    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Date</th>
                                    <th>Total Price</th>
                                    <th>Status</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($order['id']) ?></td>
                                        <td><?= format_date($order['created_at']) ?></td>
                                        <td>RM<?= format_price($order['total_price']) ?></td>
                                        <td><?= htmlspecialchars($order['status']) ?></td>
                                        <td>
                                            <button class="btn btn-info" onclick="window.location.href='invoice.php?order_id=<?= htmlspecialchars($order['id']) ?>'">
                                                View Invoice
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once 'layout/footer.php'; ?>