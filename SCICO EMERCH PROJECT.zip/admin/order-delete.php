<?php
require_once '../config/db.php';

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

if (isset($_GET['id'])) {
    $order_id = intval($_GET['id']);

    // Delete order from database
    $sql_delete = "DELETE FROM `orders` WHERE id = ?";
    $stmt_delete = mysqli_prepare($conn, $sql_delete);
    mysqli_stmt_bind_param($stmt_delete, 'i', $order_id);
    mysqli_stmt_execute($stmt_delete);
    mysqli_stmt_close($stmt_delete);

    echo "<script>alert('Order deleted successfully!');</script>";
    echo "<script>window.location.href = 'order-list.php';</script>";
}
