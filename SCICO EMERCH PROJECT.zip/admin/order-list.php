<?php $title = "Order List"; ?>
<?php include_once 'layout/header.php'; ?>
<?php
// $sql_orders = "SELECT 
//                     o.id,
//                     u.name AS customer_name,
//                     p.name AS product,
//                     od.quantity,
//                     o.status
//                 FROM 
//                     orders o
//                     JOIN users u ON o.user_id = u.id
//                     JOIN order_details od ON o.id = od.order_id
//                     JOIN products p ON od.product_id = p.id
//                     LEFT JOIN product_variants pv ON od.variant_id = pv.id
//                 ORDER BY 
//                     o.created_at DESC
//             ";

// SORT DESC
$sql_orders = "SELECT 
                    o.id,
                    u.name AS customer_name,
                    o.status,
                    o.payment_proof,
                    o.invoice_number
                FROM `orders` o
                JOIN users u ON o.user_id = u.id
                ORDER BY o.created_at DESC";
$result_orders = mysqli_query($conn, $sql_orders);

?>
<div class="container-fluid">
    <h2><?= $title; ?></h2>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Customer Name</th>
                <th>Invoice Number</th>
                <th>Payment Proof</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php

            if (!$result_orders) {
                echo "<tr><td colspan='6'>Error: " . mysqli_error($conn) . "</td></tr>";
            } else {
                while ($order = mysqli_fetch_assoc($result_orders)) : ?>
                    <tr>
                        <td><?php echo htmlspecialchars($order['id']); ?></td>
                        <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                        <td><?php echo htmlspecialchars($order['invoice_number']); ?></td>
                        <td>
                            <button class="btn btn-secondary" onclick="window.open('../assets/payment_proofs/<?php echo htmlspecialchars($order['payment_proof']); ?>', '_blank')">
                                <i class='bx bx-show'></i> View Proof
                            </button>
                        </td>
                        <td>
                            <select class="form-control" data-order-id="<?php echo $order['id']; ?>">
                                <option value="pending" <?php echo $order['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="delivered" <?php echo $order['status'] == 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                                <option value="cancelled" <?php echo $order['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                            </select>
                        </td>
                        <td>
                            <button class="btn btn-info" onclick="window.location.href='invoice.php?order_id=<?php echo $order['id']; ?>'">
                                View Invoice
                            </button>
                            <a href="order-delete.php?id=<?php echo $order['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this order?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php } ?>
        </tbody>
    </table>
</div>
<script>
    document.querySelectorAll('select[data-order-id]').forEach(select => {
        select.addEventListener('change', function() {
            const orderId = this.getAttribute('data-order-id');
            const status = this.value;

            fetch('order-update-status.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        order_id: orderId,
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Order status updated successfully.');
                    } else {
                        alert('Error updating order status: ' + data.error);
                    }
                })
                .catch(error => console.error('Error:', error));
        });
    });
</script>

<?php include_once 'layout/footer.php'; ?>