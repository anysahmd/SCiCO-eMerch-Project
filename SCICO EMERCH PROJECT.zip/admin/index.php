<?php $title = "Admin Dashboard"; ?>
<?php include_once 'layout/header.php'; ?>
<?php
$sql_users = "SELECT COUNT(*) as total FROM `users`";
$result_users = mysqli_query($conn, $sql_users);
$users = mysqli_fetch_assoc($result_users);

$sql_orders = "SELECT COUNT(*) as total FROM `orders`";
$result_orders = mysqli_query($conn, $sql_orders);
$orders = mysqli_fetch_assoc($result_orders);

$sql_products = "SELECT COUNT(*) as total FROM `products`";
$result_products = mysqli_query($conn, $sql_products);
$products = mysqli_fetch_assoc($result_products);

$sql_revenue = "SELECT * FROM `orders` WHERE `status` = 'delivered'";
$result_revenue = mysqli_query($conn, $sql_revenue);
$total_revenue = 0;
while ($row = mysqli_fetch_assoc($result_revenue)) {
  $total_revenue += $row['total_price'];
}

$sql_user = "SELECT * FROM `users`";
$result_user = mysqli_query($conn, $sql_user);


$sql_recent_orders = "SELECT 
    o.id AS `id`,
    o.invoice_number AS `invoice_number`,
    u.name AS `customer_name`,
    o.status AS `status`,
    o.created_at AS `created_at`
FROM 
    orders o
    JOIN users u ON o.user_id = u.id
ORDER BY 
    o.created_at DESC
LIMIT 5";
$result_recent_orders = mysqli_query($conn, $sql_recent_orders);
?>

<div class="container-fluid">

  <div class="cards">
    <div class="card" data-tooltip="Total registered users">
      <div>
        <h3><?php echo $users['total']; ?></h3>
        <p>Users</p>
      </div>
      <i class="bx bx-user"></i>
    </div>
    <div class="card" data-tooltip="Total orders placed">
      <div>
        <h3><?php echo $orders['total']; ?></h3>
        <p>Orders</p>
      </div>
      <i class="bx bx-cart"></i>
    </div>
    <div class="card" data-tooltip="Total products available">
      <div>
        <h3><?php echo $products['total']; ?></h3>
        <p>Products</p>
      </div>
      <i class="bx bx-store"></i>
    </div>
    <div class="card red" data-tooltip="Total revenue">
      <div>
        <h3>RM <?= number_format($total_revenue, 2); ?></h3>
        <p>Income</p>
      </div>
      <i class="bx bx-wallet"></i>
    </div>
  </div>

  <div class="section">
    <div class="recent-orders">
      <h3>Recent Orders</h3>
      <table role="grid">
        <thead>
          <tr>
            <th>INVOICE</th>
            <th>Customer</th>
            <th>Details</th>
            <th>Status</th>
            <th>Created At</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($order = mysqli_fetch_assoc($result_recent_orders)) : ?>
            <tr>
              <td><?php echo htmlspecialchars($order['invoice_number'] ?? 'N/A'); ?></td>
              <td><?php echo $order['customer_name']; ?></td>
              <td>
                <?php

                $sql_details = "SELECT od.*, p.name AS product_name, pv.variant_name 
                          FROM order_details od 
                          JOIN products p ON od.product_id = p.id 
                          LEFT JOIN product_variants pv ON od.variant_id = pv.id 
                          WHERE od.order_id = ?";
                $stmt_details = mysqli_prepare($conn, $sql_details);
                mysqli_stmt_bind_param($stmt_details, 'i', $order['id']);
                mysqli_stmt_execute($stmt_details);
                $result_details = mysqli_stmt_get_result($stmt_details);
                $order_details = mysqli_fetch_all($result_details, MYSQLI_ASSOC);
                mysqli_stmt_close($stmt_details);
                if ($order_details) {
                  foreach ($order_details as $detail) {
                    echo htmlspecialchars($detail['product_name']) . ' (' . htmlspecialchars($detail['variant_name']) . ') x ' . intval($detail['quantity']) . '<br>';
                  }
                } else {
                  echo "No details available";
                }
                ?>
              </td>
              <td><span class="badge <?php echo $order['status'] == 'delivered' ? 'green' : 'red'; ?>"><?php echo ucfirst($order['status']); ?></span></td>
              <td><?php echo $order['created_at']; ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>

    <div class="users">
      <h3>Users</h3>
      <ul role="list">
        <?php while ($user = mysqli_fetch_assoc($result_user)) : ?>
          <li>
            <span><?php echo $user['username']; ?></span>
            <small>User</small>
          </li>
        <?php endwhile; ?>
      </ul>
    </div>
  </div>
</div>
<?php include_once 'layout/footer.php'; ?>