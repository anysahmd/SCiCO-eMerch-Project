<?php $title = "Profile"; ?>
<?php include_once 'layout/header.php'; ?>
<div class="container-fluid">
    <h2><?php echo $title; ?></h2>
    <div class="profile-info">
        <h3>Profile Information</h3>
        <p><strong>Name:</strong> <?php echo $admin['username']; ?></p>
        <p><strong>Email:</strong> <?php echo $admin['email']; ?></p>
        <p><strong>Role:</strong> Admin</p>
    </div>
</div>
<?php include_once 'layout/footer.php'; ?>