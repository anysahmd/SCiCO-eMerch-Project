<?php require_once '../config/db.php'; ?>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM `admin` WHERE `username` = '$username' OR `email` = '$username'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row['password'])) {
            $_SESSION['admin'] = $row;
            echo "<script>alert('Login successful!'); window.location.href = 'index.php';</script>";
        } else {
            echo "<script>alert('Invalid username or password');</script>";
        }
    } else {
        echo "<script>alert('Invalid username or password');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/login.css?v=1.0">
</head>

<body>
    <div class="wrapper">
        <form action="" method="POST">
            <h1>Admin Login</h1>
            <div class="input-box">
                <input type="text" name="username" placeholder="Admin Username" required>
                <i class='bx bxs-user'></i>
            </div>
            <br>
            <div class="input-box">
                <input type="password" name="password" placeholder="Password" required>
                <i class='bx bxs-lock-alt'></i>
            </div>
            <br>

            <button type="submit" class="btn">Login</button>
            <div class="register-link">
                <p>Not an admin? <a href="create-account.php">Register as Admin</a></p>
            </div>
        </form>
    </div>
</body>

</html>