<?php
$title = isset($_GET['id']) ? "Edit Product" : "Add Product";
include_once 'layout/header.php';
if (isset($_GET['id'])) {
    $sql = "SELECT * FROM `products` WHERE `id`=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $_GET['id']);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $product = mysqli_fetch_assoc($result);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $type = $_POST['type'];
    $image = $_FILES['image']['name'] ?? '';
    $variants = $_POST['variants'] ?? [];


    // Handle file upload
    if ($image) {
        $target_dir = "../assets/img/product/";
        $target_file = $target_dir . basename($image);
        move_uploaded_file($_FILES['image']['tmp_name'], $target_file);
    } else {



        $image = isset($_GET['id']) ? $product['image'] ?? 'default.png' : 'default.png';
    }

    // Start transaction
    mysqli_begin_transaction($conn);

    try {
        if (isset($_GET['id'])) {
            // Update product

            $sql = "UPDATE `products` SET `name`=?, `description`=?, `price`=?, `type`=?, `image`=? WHERE `id`=?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssdssi", $name, $description, $price, $type, $image, $_GET['id']);
            mysqli_stmt_execute($stmt);

            // Delete existing variants
            $sql = "DELETE FROM `product_variants` WHERE `product_id`=?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "i", $_GET['id']);
            mysqli_stmt_execute($stmt);
        } else {
            // Add new product
            $sql = "INSERT INTO `products` (`name`, `description`, `price`, `type`, `image`) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssdss", $name, $description, $price, $type, $image);
            mysqli_stmt_execute($stmt);
            $product_id = mysqli_insert_id($conn);
        }

        // Insert variants
        if (!empty($variants)) {
            $product_id = isset($_GET['id']) ? $_GET['id'] : $product_id;
            $sql = "INSERT INTO `product_variants` (`product_id`, `variant_name`, `variant_stock`) VALUES (?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);

            foreach ($variants as $variant) {
                if (!empty($variant['name']) && isset($variant['stock'])) {
                    mysqli_stmt_bind_param($stmt, "isi", $product_id, $variant['name'], $variant['stock']);
                    mysqli_stmt_execute($stmt);
                }
            }
        }

        mysqli_commit($conn);
        echo "<script>alert('Product saved successfully!'); window.location.href = 'product-list.php';</script>";
    } catch (Exception $e) {
        mysqli_rollback($conn);
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
    }
}

$product = null;
$variants = [];
if (isset($_GET['id'])) {
    // Fetch product
    $sql = "SELECT * FROM `products` WHERE `id`=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $_GET['id']);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $product = mysqli_fetch_assoc($result);

    // Fetch variants
    $sql = "SELECT * FROM `product_variants` WHERE `product_id`=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $_GET['id']);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $variants = mysqli_fetch_all($result, MYSQLI_ASSOC);
}
?>

<div class="container-fluid">
    <h2><?php echo $title; ?></h2>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" id="name" class="form-control" value="<?php echo htmlspecialchars($product['name'] ?? ''); ?>" required>
        </div>
        <div class="form-group">
            <label for="description">Description</label>
            <textarea name="description" id="description" class="form-control"><?php echo htmlspecialchars($product['description'] ?? ''); ?></textarea>
        </div>
        <div class="form-group">
            <label for="price">Price</label>
            <input type="number" step="0.01" name="price" id="price" class="form-control" value="<?php echo htmlspecialchars($product['price'] ?? ''); ?>" required>
        </div>
        <div class="form-group">
            <label for="type">Type</label>
            <select name="type" id="type" class="form-control" required>
                <option value="" disabled <?php echo !isset($product['type']) ? 'selected' : ''; ?>>Select Type</option>
                <option value="color" <?php echo ($product['type'] ?? '') === 'color' ? 'selected' : ''; ?>>Color</option>
                <option value="size" <?php echo ($product['type'] ?? '') === 'size' ? 'selected' : ''; ?>>Size</option>
                <option value="material" <?php echo ($product['type'] ?? '') === 'material' ? 'selected' : ''; ?>>Material</option>
            </select>
        </div>
        <div class="form-group">
            <label for="image">Image</label><br>
            <img src="../assets/img/product/<?php echo htmlspecialchars($product['image'] ?? 'default.png'); ?>" alt="Product Image" class="img-thumbnail mb-2" style="max-width: 250px;" id="product_image" onerror="this.src='../assets/img/product/default.png'">
            <input type="file" name="image" id="image" class="form-control">
        </div>

        <div class="form-group">
            <label>Variants</label>
            <div id="variants-container">
                <?php if (!empty($variants)): ?>
                    <?php foreach ($variants as $index => $variant): ?>
                        <div class="variant-row mb-2 d-flex">
                            <input type="text" name="variants[<?php echo $index; ?>][name]" class="form-control variant-name mr-2" value="<?php echo htmlspecialchars($variant['variant_name']); ?>" placeholder="Variant Name" required>
                            <input type="number" name="variants[<?php echo $index; ?>][stock]" class="form-control variant-stock mr-2" value="<?php echo htmlspecialchars($variant['variant_stock']); ?>" placeholder="Variant Stock" required>
                            <button type="button" class="btn btn-danger remove-variant">Remove</button>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <button type="button" id="add-variant" class="btn btn-secondary mt-2">Add Variant</button>
        </div>

        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>

<script>
    let variantCount = <?php echo count($variants) ?: 0; ?>;

    document.getElementById('add-variant').addEventListener('click', () => {
        const container = document.getElementById('variants-container');
        const variantRow = document.createElement('div');
        variantRow.className = 'variant-row mb-2 d-flex';
        variantRow.innerHTML = `
        <input type="text" name="variants[${variantCount}][name]" class="form-control variant-name mr-2" placeholder="Variant Name" required>
        <input type="number" name="variants[${variantCount}][stock]" class="form-control variant-stock mr-2" placeholder="Variant Stock" required>
        <button type="button" class="btn btn-danger remove-variant">Remove</button>
    `;
        container.appendChild(variantRow);
        variantCount++;
    });

    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('remove-variant')) {
            e.target.parentElement.remove();
        }
    });

    document.getElementById('image').addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('product_image').src = e.target.result;
            };
            reader.readAsDataURL(file);
        } else {
            document.getElementById('product_image').src = '../assets/img/product/default.png';
        }
    });
</script>

<?php include_once 'layout/footer.php'; ?>