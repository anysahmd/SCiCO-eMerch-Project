<?php require_once '../config/db.php'; ?>
<?php
if (isset($_GET['id'])) {
    $product_id = $_GET['id'];

    // check if the product exists
    $sql_product = "SELECT * FROM `products` WHERE `id`='$product_id'";
    $result_product = mysqli_query($conn, $sql_product);
    if (mysqli_num_rows($result_product) > 0) {
        $product = mysqli_fetch_assoc($result_product);
        // delete product
        $sql_delete = "DELETE FROM `products` WHERE `id`='$product_id'";
        if (mysqli_query($conn, $sql_delete)) {
            // delete product variants
            $sql_delete_variants = "DELETE FROM `product_variants` WHERE `product_id`='$product_id'";
            mysqli_query($conn, $sql_delete_variants);
            // delete product images
            $image_path = '../assets/img/product/' . $product['image'];
            if (file_exists($image_path) && $product['image'] != 'default.png') {
                unlink($image_path);
            }

            echo "<script>alert('Product deleted successfully!'); window.location.href = 'product-list.php';</script>";
        } else {
            echo "<script>alert('Error deleting product: " . mysqli_error($conn) . "');</script>";
        }
    } else {
        echo "<script>alert('Product not found!'); window.location.href = 'product-list.php';</script>";
    }
}
