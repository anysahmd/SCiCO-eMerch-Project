<?php $title = "Settings"; ?>
<?php include_once 'layout/header.php'; ?>
<?php
$admin_id = $admin['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate input
    if (empty($username) || empty($email)) {
        $error = "Username and email are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {

        if (!empty($password)) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $sql = "UPDATE `admin` SET `username`=?, `email`=?, `password`=? WHERE `id`=?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "sssi", $username, $email, $hashed_password, $admin_id);
        } else {
            $sql = "UPDATE `admin` SET `username`=?, `email`=? WHERE `id`=?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssi", $username, $email, $admin_id);
        }
        echo "<script>alert('Settings updated successfully!');</script>";
        if (mysqli_stmt_execute($stmt)) {
            $success = "Settings updated successfully!";
        } else {
            $error = "Error updating settings.";
        }
    }

    // Handle profile image upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "../assets/img/user/";
        $target_file = $target_dir . basename($_FILES['profile_picture']['name']);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if file is an image
        $check = getimagesize($_FILES['profile_picture']['tmp_name']);
        if ($check !== false) {
            // Move uploaded file
            if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_file)) {
                // Update profile image in database
                $sql = "UPDATE `admin` SET `profile_picture`=? WHERE `id`=?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "si", $_FILES['profile_picture']['name'], $admin_id);
                mysqli_stmt_execute($stmt);
                echo "<script>alert('Profile image updated successfully!'); window.location.href = 'settings.php';</script>";
            } else {
                $error = "Error uploading profile image.";
            }
        } else {
            $error = "File is not an image.";
        }
    }
}

?>
<div class="container-fluid">
    <h2><?php echo $title; ?></h2>
    <div class="settings-info">
        <h3>Account Settings</h3>
        <?php if (isset($error)) : ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if (isset($success)) : ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" class="form-control" name="username" value="<?php echo $admin['username']; ?>" required />
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" class="form-control" name="email" value="<?php echo $admin['email']; ?>" required />
            </div>
            <div class="form-group">
                <label for="profile_picture">Profile Image</label>
                <img src="../assets/img/user/<?php echo $admin['profile_picture']; ?>" alt="Profile picture" class="img-thumbnail mb-2" style="max-width: 250px;" id="profile_image" />
                <br>
                <input type="file" class="form-control-file" id="profile_picture" name="profile_picture" accept="image/*" />
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" />
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <input type="password" class="form-control" id="confirm_password" name="confirm_password" />
            </div>


            <button type="submit" class="btn btn-primary">Save Changes</button>
        </form>
    </div>
</div>
<?php include_once 'layout/footer.php'; ?>
<script>
    document.getElementById('profile_picture').addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('profile_image').src = e.target.result;
            };
            reader.readAsDataURL(file);
        }
    });
</script>