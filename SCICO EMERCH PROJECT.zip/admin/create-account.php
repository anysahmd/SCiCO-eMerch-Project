<?php
require_once '../config/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if username or email already exists
    $check_sql = "SELECT * FROM `admin` WHERE `username` = '$username' OR `email` = '$email'";
    $check_result = mysqli_query($conn, $check_sql);

    if (mysqli_num_rows($check_result) > 0) {
        echo "<script>alert('Username or email already exists!');</script>";
    } else {
        $password = password_hash($password, PASSWORD_DEFAULT);
        $insert_sql = "INSERT INTO `admin` (`username`, `email`, `password`) VALUES ('$username', '$email', '$password')";
        if (mysqli_query($conn, $insert_sql)) {
            echo "<script>alert('Account created successfully.'); window.location.href = 'login.php';</script>";
        } else {
            echo "<script>alert('Error creating account: " . mysqli_error($conn) . "');</script>";
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Create Account</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/login.css?v=1.0">
</head>

<body>
    <div class="wrapper">
        <form action="" method="POST">
            <h1>Create Account</h1>
            <div class="input-box">
                <input type="text" name="username" placeholder="Username" required>
                <i class='bx bxs-user'></i>
            </div>
            <br>
            <div class="input-box">
                <input type="email" name="email" placeholder="Email" required>
                <i class='bx bxs-envelope'></i>
            </div>
            <br>
            <div class="input-box">
                <input type="password" name="password" placeholder="Password" required>
                <i class='bx bxs-lock-alt'></i>
            </div>
            <br>
            <button type="submit" class="btn">Create Account</button>
            <div class="register-link">
                <p>Already have an account? <a href="login.php">Login</a></p>
            </div>
        </form>
    </div>
</body>

</html>