<?php
$title = "Product List";
include_once 'layout/header.php';

// Fetch products and their variants
$sql_products = "
    SELECT p.*, GROUP_CONCAT(v.variant_name) as variant_names, SUM(v.variant_stock) as total_stock
    FROM `products` p
    LEFT JOIN `product_variants` v ON p.id = v.product_id
    GROUP BY p.id
";
$result_products = mysqli_query($conn, $sql_products);
?>

<div class="container-fluid">
    <h2>
        Product List
        <a href="product-form.php" class="btn btn-primary" style="float: right;">Add New Product</a>
    </h2>
    <div style="background-color: #f8f9fa; padding: 20px; border-radius: 5px;">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Type</th>
                    <th>Variants</th>
                    <th>Total Stock</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($product = mysqli_fetch_assoc($result_products)) : ?>
                    <tr>
                        <td><?php echo $product['id']; ?></td>
                        <td>
                            <img 
                                src="../assets/img/product/<?php echo htmlspecialchars($product['image'] ?: 'default.png'); ?>" 
                                alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                width="100" 
                                onerror="this.src='../assets/img/product/default.png'"
                            >
                        </td>
                        <td><?php echo htmlspecialchars($product['name']); ?></td>
                        <td>RM <?php echo number_format($product['price'], 2); ?></td>
                        <td><?php echo ucfirst(htmlspecialchars($product['type'] ?? 'N/A')); ?></td>
                        <td>
                            <?php 
                            echo $product['variant_names'] 
                                ? htmlspecialchars($product['variant_names']) 
                                : 'No variants'; 
                            ?>
                        </td>
                        <td><?php echo $product['total_stock'] ?? 0; ?></td>
                        <td>
                            <a href="product-form.php?id=<?php echo $product['id']; ?>" class="btn btn-secondary btn-sm">Edit</a>
                            <a href="product-delete.php?id=<?php echo $product['id']; ?>" 
                               class="btn btn-danger btn-sm" 
                               onclick="return confirm('Are you sure you want to delete this product?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include_once 'layout/footer.php'; ?>