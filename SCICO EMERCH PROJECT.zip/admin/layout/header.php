<?php
require_once '../config/db.php';
if (!isset($_SESSION['admin'])) {
    echo "<script>alert('You must be logged in as an admin to access this page.'); window.location.href = 'login.php';</script>";
    exit();
}

$sql_admin = "SELECT * FROM `admin` WHERE `id` = " . $_SESSION['admin']['id'];
$result_admin = mysqli_query($conn, $sql_admin);
$admin = mysqli_fetch_assoc($result_admin);


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin Dashboard - SCiCO</title>
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;900&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/admin.css?v=1.0" />
</head>

<body>
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h2>SCiCO</h2>
            <button class="hamburger" aria-label="Toggle menu" onclick="toggleSidebar()">
                <i class="bx bx-menu"></i>
            </button>
        </div>
        <nav class="sidebar-nav">
            <a href="index.php" <?= (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'class="active"' : ''; ?>><i class="bx bx-grid-alt"></i> Dashboard</a>
            <a href="user-list.php" <?= (basename($_SERVER['PHP_SELF']) == 'user-list.php') ? 'class="active"' : ''; ?>><i class="bx bx-user"></i> Users</a>
            <a href="order-list.php" <?= (basename($_SERVER['PHP_SELF']) == 'order-list.php') ? 'class="active"' : ''; ?>><i class="bx bx-cart"></i> Orders</a>
            <a href="product-list.php" <?= (in_array(basename($_SERVER['PHP_SELF']), ['product-list.php', 'product-form.php'])) ? 'class="active"' : ''; ?>><i class="bx bx-package"></i> Products</a>

        </nav>
        <div class="logout" role="button" tabindex="0" onclick="logout()">Log Out</div>
    </div>

    <div class="main-content">
        <div class="topbar">
            <div class="welcome">
                <strong>Welcome back, <?php echo $admin['username']; ?>!</strong>
            </div>
            <div class="profile" role="button" tabindex="0" onclick="toggleProfileMenu()">
                <p><strong><?php echo $admin['email']; ?></strong><br /><small>Admin</small></p>
                <img src="../assets/img/user/<?= $admin['profile_picture']; ?>" alt="Profile picture" />
                <div class="profile-menu" id="profileMenu">
                    <a href="profile.php">Profile</a>
                    <a href="settings.php">Settings</a>
                    <a href="#" onclick="logout()">Logout</a>
                </div>
            </div>
        </div>