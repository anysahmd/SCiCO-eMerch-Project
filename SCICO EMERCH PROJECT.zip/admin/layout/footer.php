    <footer>
      <p>&copy; <?php echo date('Y'); ?> SCiCO. All rights reserved.</p>
    </footer>
  </div>

  <script>
    function toggleSidebar() {
      document.getElementById('sidebar').classList.toggle('active');
    }

    function toggleProfileMenu() {
      document.getElementById('profileMenu').classList.toggle('active');
    }

    function logout() {
      if (confirm('Are you sure you want to log out?')) {
        window.location.href = 'logout.php';
      }
    }

    // Close profile menu when clicking outside
    document.addEventListener('click', function(event) {
      const profile = document.querySelector('.profile');
      const profileMenu = document.getElementById('profileMenu');
      if (!profile.contains(event.target)) {
        profileMenu.classList.remove('active');
      }
    });
  </script>
</body>

</html>