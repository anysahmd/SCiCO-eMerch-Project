<?php $title = "User List"; ?>
<?php include_once 'layout/header.php'; ?>
<?php
$sql_users = "SELECT * FROM `users`";
$result_users = mysqli_query($conn, $sql_users);
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="" style="background-color: #f8f9fa; padding: 20px; border-radius: 5px;">
                <h2 style="margin-bottom: 20px;">User List</h2>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Joined Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($user = mysqli_fetch_assoc($result_users)) : ?>
                                <tr>
                                    <td><?php echo $user['id']; ?></td>
                                    <td><?php echo $user['username']; ?></td>
                                    <td><?php echo $user['email']; ?></td>
                                    <td><?php echo date('d-m-Y H:i:s', strtotime($user['created_at'])); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once 'layout/footer.php'; ?>