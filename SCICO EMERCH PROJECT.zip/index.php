<?php
require_once 'config/db.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>SCiCO e Merch</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet" />
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }

    body {
      background-color: #fff;
      color: #000;
    }

    header {
      width: 100%;
      padding: 20px 80px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .logo img {
      width: 50px;
    }

    nav ul {
      display: flex;
      list-style: none;
      gap: 40px;
    }

    nav ul li a {
      text-decoration: none;
      color: #000;
      font-weight: 500;
      position: relative;
    }

    nav ul li a:hover,
    nav ul li a.active {
      color: rgb(0, 0, 0);
    }

    nav ul li a.active::after {
      content: '';
      position: absolute;
      left: 0;
      bottom: -5px;
      width: 100%;
      height: 2px;
      background: #131394;
    }

    .hero {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 40px 80px;
    }

    .hero-text {
      max-width: 50%;
    }

    .hero-text p {
      font-size: 16px;
      margin-bottom: 10px;
    }

    .hero-text h1 {
      font-size: 48px;
      color: #131394;
      font-weight: 700;
    }

    .hero-text h2 {
      font-size: 24px;
      color: #333;
      font-weight: 600;
      margin-bottom: 20px;
    }

    .hero-text .btn {
      background: #131394;
      color: #fff;
      padding: 12px 25px;
      border: none;
      border-radius: 6px;
      font-weight: 500;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
      transition: 0.3s;
    }

    .hero-text .btn:hover {
      background: rgb(4, 8, 133);
    }

    .hero-img img {
      max-width: 500px;
    }

    .social {
      position: absolute;
      bottom: 30px;
      left: 80px;
      display: flex;
      gap: 20px;
    }

    .social a {
      color: #000;
      font-size: 20px;
    }

    @media (max-width: 768px) {
      .hero {
        flex-direction: column;
        padding: 20px;
        text-align: center;
      }

      .hero-text {
        max-width: 100%;
      }

      .hero-img img {
        width: 100%;
        margin-top: 20px;
      }

      header {
        padding: 20px;
        flex-direction: column;
      }

      nav ul {
        margin-top: 10px;
        gap: 20px;
      }

      .social {
        left: 20px;
        bottom: 20px;
      }
    }
  </style>
</head>

<body>

  <!-- Navigation Bar -->
  <header>
    <div class="logo">
      <img src="assets/img/logo.jpg" alt="MYTECC Logo" />
    </div>
    <nav>
      <ul>
        <li><a href="shop.php" class="active">Shop</a></li>
        <li><a href="login.php">Log In</a></li>
        <li><a href="register.php">Sign Up</a></li>
        <li><a href="admin/login.php">Admin</a></li>
      </ul>
    </nav>

  </header>

  <!-- Hero Section -->
  <section class="hero">
    <div class="hero-text">
      <p>Hello, Welcome to</p>
      <h1>SCiCO</h1>
      <h2>e Merch System</h2>
      <a href="login.php" class="btn">Get Started</a>

    </div>
    <div class="hero-img">
      <img src="assets/img/homepage.jpg" alt="eCommerce Illustration" />
    </div>
  </section>

  <!-- Social Icons -->
  <div class="social">
    <a href="#"><i class='bx bxl-instagram'></i></a>
    <a href="#"><i class='bx bxl-twitter'></i></a>
  </div>

</body>

</html>