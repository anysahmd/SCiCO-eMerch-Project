<?php
require_once 'config/db.php';

// Initialize variables to retain form input values
$name = $username = $email = $address = $phone = '';
$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate input
    $name = trim($_POST['name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Basic validation
    if (empty($name)) $errors[] = "Name is required.";
    if (empty($username)) $errors[] = "Username is required.";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Valid email is required.";
    if (empty($address)) $errors[] = "Address is required.";
    if (empty($phone) || !preg_match("/^[0-9]{10,15}$/", $phone)) $errors[] = "Valid phone number (10-15 digits) is required.";
    if (empty($password)) $errors[] = "Password is required.";
    if ($password !== $confirm_password) $errors[] = "Passwords do not match.";

    // Check if username or email already exists
    if (empty($errors)) {
        $check_sql = "SELECT * FROM `users` WHERE `username` = ? OR `email` = ?";
        $stmt = mysqli_prepare($conn, $check_sql);
        mysqli_stmt_bind_param($stmt, "ss", $username, $email);
        mysqli_stmt_execute($stmt);
        $check_result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($check_result) > 0) {
            $errors[] = "Username or email already exists!";
        }
        mysqli_stmt_close($stmt);
    }

    // If no errors, proceed with registration
    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO `users` (`name`, `username`, `email`, `address`, `phone`, `password`) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssssss", $name, $username, $email, $address, $phone, $hashed_password);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Registration successful!'); window.location.href = 'login.php';</script>";
        } else {
            $errors[] = "Error: " . mysqli_error($conn);
        }
        mysqli_stmt_close($stmt);
    }

    // Display errors if any
    if (!empty($errors)) {
        $error_message = implode("\\n", array_map('addslashes', $errors));
        echo "<script>alert('$error_message');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up Page</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/login.css?v=1.0">
</head>

<body>
    <div class="wrapper" style="width:100%;margin: auto;">
        <form action="" method="POST">
            <h1>Sign Up</h1>
            <div class="form-grid">
                <div class="input-box">
                    <input type="text" placeholder="Full Name" name="name" required value="<?php echo htmlspecialchars($name); ?>">
                    <i class='bx bxs-user'></i>
                </div>
                <div class="input-box">
                    <input type="text" placeholder="Username" name="username" required value="<?php echo htmlspecialchars($username); ?>">
                    <i class='bx bxs-user'></i>
                </div>
                <div class="input-box">
                    <input type="email" placeholder="Email" name="email" required value="<?php echo htmlspecialchars($email); ?>">
                    <i class='bx bxs-envelope'></i>
                </div>
                <div class="input-box">
                    <input type="text" placeholder="Address" name="address" required value="<?php echo htmlspecialchars($address); ?>">
                    <i class='bx bxs-home'></i>
                </div>
                <div class="input-box">
                    <input type="text" placeholder="Phone Number" name="phone" required value="<?php echo htmlspecialchars($phone); ?>">
                    <i class='bx bxs-phone'></i>
                </div>
                <div class="input-box">
                    <input type="password" placeholder="Password" name="password" required>
                    <i class='bx bxs-lock-alt'></i>
                </div>
                <div class="input-box">
                    <input type="password" placeholder="Confirm Password" name="confirm_password" required>
                    <i class='bx bxs-lock-alt'></i>
                </div>
            </div>
            <button type="submit" class="btn">Sign Up</button>
            <div class="register-link">
                <p>Already have an account? <a href="login.php">Login</a></p>
            </div>
        </form>
    </div>
</body>

</html>