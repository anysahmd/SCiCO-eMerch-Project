<?php
$title = "Invoice";
include_once 'layout/header.php';

// Fetch product details for cart items
function get_cart_items($order_id)
{
    global $conn;
    if (!$order_id) {
        return [];
    }

    $sql_order = "SELECT od.*, p.name, p.price, pv.variant_name 
                  FROM order_details od 
                  JOIN products p ON od.product_id = p.id 
                  LEFT JOIN product_variants pv ON od.variant_id = pv.id 
                  WHERE od.order_id = ?";

    $stmt = mysqli_prepare($conn, $sql_order);
    if (!$stmt) {
        return [];
    }

    mysqli_stmt_bind_param($stmt, 'i', $order_id);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);
    $items = mysqli_fetch_all($result, MYSQLI_ASSOC);
    mysqli_stmt_close($stmt);

    return array_map(function ($item) {
        return [
            'name' => $item['name'],
            'price' => floatval($item['price']),
            'variant_name' => $item['variant_name'] ?? '',
            'quantity' => intval($item['quantity'])
        ];
    }, $items);
}

// Get order ID from session (assuming it's stored after order creation)
$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : null;

$sql_order_check = "SELECT * FROM orders WHERE id = ?";
$stmt_order_check = mysqli_prepare($conn, $sql_order_check);
mysqli_stmt_bind_param($stmt_order_check, 'i', $order_id);
mysqli_stmt_execute($stmt_order_check);
$result_order_check = mysqli_stmt_get_result($stmt_order_check);
$order = mysqli_fetch_assoc($result_order_check);
mysqli_stmt_close($stmt_order_check);

// Get cart items and calculate subtotal
$cart_items = get_cart_items($order_id);
$subtotal = array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $cart_items));
$delivery_fee = 5.00;
$total = $subtotal + $delivery_fee;

// Generate or retrieve invoice number


// Customer details
$customer_id = $order['user_id'] ?? null;
$sql_customer = "SELECT name, email, address, phone FROM users WHERE id = ?";
$stmt_customer = mysqli_prepare($conn, $sql_customer);
mysqli_stmt_bind_param($stmt_customer, 'i', $customer_id);
mysqli_stmt_execute($stmt_customer);
$result_customer = mysqli_stmt_get_result($stmt_customer);
$customer = mysqli_fetch_assoc($result_customer);
mysqli_stmt_close($stmt_customer);
?>

<style>
    .invoice-box {
        background: white;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        max-width: 950px;
        margin: 0 auto;
    }

    .invoice-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 30px;
        flex-wrap: wrap;
        gap: 20px;
    }

    .company-details,
    .invoice-info,
    .customer-details {
        font-size: 16px;
        color: #4b5563;
        line-height: 1.6;
    }

    .company-details p,
    .invoice-info p,
    .customer-details p {
        margin: 0;
    }

    .company-details strong,
    .invoice-info strong,
    .customer-details strong {
        color: #1e3a8a;
        font-weight: 600;
    }

    .invoice-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 30px;
    }

    .invoice-table th,
    .invoice-table td {
        padding: 12px;
        border: 1px solid #e2e8f0;
        text-align: left;
        font-size: 14px;
        color: #4b5563;
    }

    .invoice-table th {
        background: #f3f4f6;
        font-weight: 600;
        color: #1e3a8a;
    }

    .invoice-table .total {
        font-weight: 600;
        color: #0e0581;
    }

    .terms {
        font-size: 14px;
        color: #6b7280;
        margin-bottom: 20px;
        text-align: center;
        font-style: italic;
    }

    .print-btn {
        display: flex;
        align-items: center;
        gap: 8px;
        width: 100%;
        max-width: 200px;
        margin: 0 auto;
        justify-content: center;
    }

    .empty-cart-message {
        text-align: center;
        font-size: 16px;
        color: #6b7280;
        margin: 20px 0;
    }

    @media (max-width: 768px) {
        .invoice-box {
            padding: 20px;
        }

        .invoice-header {
            flex-direction: column;
            align-items: flex-start;
        }

        .company-details,
        .invoice-info,
        .customer-details {
            font-size: 14px;
        }

        .invoice-table th,
        .invoice-table td {
            font-size: 12px;
            padding: 8px;
        }
    }

    @media (max-width: 576px) {

        .invoice-table th,
        .invoice-table td {
            font-size: 10px;
            padding: 6px;
        }

        .print-btn {
            max-width: 100%;
        }
    }

    @media print {

        .sidebar,
        .top-bar,
        .step-label,
        .print-btn,
        .payment-button {
            display: none;
        }

        .main {
            margin-left: 0;
            padding: 0;
        }

        .invoice-box {
            box-shadow: none;
            border: none;
            padding: 10px;
            max-width: 100%;
        }

        .invoice-header,
        .customer-details,
        .invoice-table {
            font-size: 12px;
        }
    }
</style>

<div class="main">
    <div class="top-bar">
        <h2>Invoice</h2>
    </div>

    <div class="step-label">
        BASKET ► <strong>PAYMENT</strong> ► INVOICE
    </div>

    <div class="invoice-box">
        <div class="invoice-header">
            <div class="company-details">
                <p><strong>SCIENCE COMPUTER SOCIETY (SCiCO)</strong><br>
                    scicoclub@gmail.com<br>
                    Universiti Teknologi Mara (UiTM),<br>
                    Kampus Machang, Kelantan</p>
            </div>
            <div class="invoice-info">
                <p>
                    <strong>Invoice: #<?= isset($order['invoice_number']) ? htmlspecialchars($order['invoice_number']) : 'N/A'; ?></strong><br>
                    Created: <?= date('d/m/Y H:i:s', strtotime($order['created_at'])); ?><br>
                    Order ID: <?php echo htmlspecialchars($order_id); ?><br>
                </p>
            </div>
        </div>

        <div class="customer-details">
            <p><strong><?php echo htmlspecialchars($customer['name']); ?></strong><br>
                <?php echo htmlspecialchars($customer['email']); ?><br>
                <?php echo htmlspecialchars($customer['address']); ?><br>
                <?php echo htmlspecialchars($customer['phone']); ?></p>
        </div>

        <table class="invoice-table">
            <thead>
                <tr>
                    <th>Item(s)</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($cart_items)): ?>
                    <tr>
                        <td colspan="2" class="empty-cart-message">No items in the invoice</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($cart_items as $item): ?>
                        <tr>
                            <td>
                                <?php echo htmlspecialchars($item['name']); ?>
                                <?php echo $item['variant_name'] ? ' - ' . htmlspecialchars($item['variant_name']) : ''; ?>
                                - RM<?php echo number_format($item['price'], 2); ?> x <?php echo $item['quantity']; ?>
                            </td>
                            <td>RM<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr>
                        <td>Delivery Fee</td>
                        <td>RM<?php echo number_format($delivery_fee, 2); ?></td>
                    </tr>
                    <tr>
                        <td class="total">Total:</td>
                        <td class="total">RM<?php echo number_format($total, 2); ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <p class="terms">Terms & Conditions Apply.</p>
        <button class="btn btn-primary print-btn" onclick="window.print()" aria-label="Print this invoice">
            <i class='bx bx-printer'></i> Print Invoice
        </button>
    </div>
</div>

<?php include_once 'layout/footer.php'; ?>