<?php require_once 'config/db.php'; ?>
<?php
session_destroy();
echo "<script>alert('You have successfully logged out.'); window.location.href = 'login.php';</script>";
exit;
